# FROM STUDIO TO SCREEN
## Visualizing Anime Trends and Explaining the Unexpected
### Lan Nguyen and Faye Le

## I. Introduction

Our group wanted to know whether the top 10000 anime has a trend in why some anime has a higher scoring than others, while trying to see if those factors predict can an anime has a higher score.

Here is what we did. 

## Library ##


```python
import pandas as pd
import time
import random
import numpy as np
import streamlit as st
import matplotlib 
matplotlib.use('Qt5Agg') 
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
```

## Dataset ##

The dataset is scraped from the website https://myanimelist.net/topanime.php. Dataset contain the top 10000 anime ranked on the 30th of October, 2024.


```python
super_df = pd.read_csv('totoro_group_data.csv')
```


```python
super_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Score</th>
      <th>Unnamed: 0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>9844.000000</td>
      <td>9844.000000</td>
      <td>5996.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5068.976534</td>
      <td>6.915924</td>
      <td>1230.670614</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2854.113609</td>
      <td>0.624616</td>
      <td>1120.037454</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>5.960000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2613.750000</td>
      <td>6.410000</td>
      <td>275.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>5075.500000</td>
      <td>6.840000</td>
      <td>744.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7537.250000</td>
      <td>7.330000</td>
      <td>2156.250000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>10000.000000</td>
      <td>9.320000</td>
      <td>3656.000000</td>
    </tr>
  </tbody>
</table>
</div>



Here we did some clean-up for the dataset.


```python
super_df = super_df.drop('Unnamed: 0', axis=1)
```


```python
super_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>URL</th>
      <th>Score</th>
      <th>Genres</th>
      <th>Episodes</th>
      <th>Premiered</th>
      <th>Studio</th>
      <th>Type</th>
      <th>Source</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Sousou no Frieren</td>
      <td>https://myanimelist.net/anime/52991/Sousou_no_...</td>
      <td>9.32</td>
      <td>Adventure, Drama, Fantasy, Shounen</td>
      <td>28</td>
      <td>Fall 2023</td>
      <td>Madhouse</td>
      <td>TV</td>
      <td>Manga</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>One Piece Fan Letter</td>
      <td>https://myanimelist.net/anime/60022/One_Piece_...</td>
      <td>9.17</td>
      <td>Action, Adventure, Fantasy, Shounen</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV Special</td>
      <td>Light novel</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Fullmetal Alchemist: Brotherhood</td>
      <td>https://myanimelist.net/anime/5114/Fullmetal_A...</td>
      <td>9.09</td>
      <td>Action, Adventure, Drama, Fantasy, Military, S...</td>
      <td>64</td>
      <td>Spring 2009</td>
      <td>Bones</td>
      <td>TV</td>
      <td>Manga</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Steins;Gate</td>
      <td>https://myanimelist.net/anime/9253/Steins_Gate</td>
      <td>9.07</td>
      <td>Drama, Sci-Fi, Suspense, Psychological, Time T...</td>
      <td>24</td>
      <td>Spring 2011</td>
      <td>White Fox</td>
      <td>TV</td>
      <td>Source not found</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Shingeki no Kyojin Season 3 Part 2</td>
      <td>https://myanimelist.net/anime/38524/Shingeki_n...</td>
      <td>9.05</td>
      <td>Action, Drama, Suspense, Gore, Military, Survi...</td>
      <td>10</td>
      <td>Spring 2019</td>
      <td>Wit Studio</td>
      <td>TV</td>
      <td>Manga</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>9839</th>
      <td>9996</td>
      <td>Garugaku. II: Lucky Stars</td>
      <td>https://myanimelist.net/anime/50495/Garugaku_I...</td>
      <td>5.96</td>
      <td>Idols (Female), Music, School</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>OLM</td>
      <td>TV</td>
      <td>Source not found</td>
    </tr>
    <tr>
      <th>9840</th>
      <td>9997</td>
      <td>Guan Hai Ce</td>
      <td>https://myanimelist.net/anime/38689/Guan_Hai_Ce</td>
      <td>5.96</td>
      <td>Action, Fantasy, Historical, Martial Arts, Mil...</td>
      <td>16</td>
      <td>Premiered season not found</td>
      <td>Tong Ming Xuan</td>
      <td>ONA</td>
      <td>Source not found</td>
    </tr>
    <tr>
      <th>9841</th>
      <td>9998</td>
      <td>Hatara Kids Mai Ham Gumi</td>
      <td>https://myanimelist.net/anime/3251/Hatara_Kids...</td>
      <td>5.96</td>
      <td>Action, Kids</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Source not found</td>
    </tr>
    <tr>
      <th>9842</th>
      <td>9999</td>
      <td>Hatsukoi Monster: Mou Chotto dake Tsuzukunja</td>
      <td>https://myanimelist.net/anime/34016/Hatsukoi_M...</td>
      <td>5.96</td>
      <td>Comedy, Romance, School, Shoujo</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Studio Deen</td>
      <td>OVA</td>
      <td>Manga</td>
    </tr>
    <tr>
      <th>9843</th>
      <td>10000</td>
      <td>Hello Kitty no Kieta Santa-san no Boushi</td>
      <td>https://myanimelist.net/anime/22481/Hello_Kitt...</td>
      <td>5.96</td>
      <td>Fantasy, Kids</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>add some</td>
      <td>OVA</td>
      <td>Source not found</td>
    </tr>
  </tbody>
</table>
<p>9844 rows × 10 columns</p>
</div>




```python
super_df['Episodes'] = pd.to_numeric(super_df['Episodes'], errors='coerce')
super_df['Episodes'] = super_df['Episodes'].astype('Int64')
super_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>URL</th>
      <th>Score</th>
      <th>Genres</th>
      <th>Episodes</th>
      <th>Premiered</th>
      <th>Studio</th>
      <th>Type</th>
      <th>Source</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Sousou no Frieren</td>
      <td>https://myanimelist.net/anime/52991/Sousou_no_...</td>
      <td>9.32</td>
      <td>Adventure, Drama, Fantasy, Shounen</td>
      <td>28</td>
      <td>Fall 2023</td>
      <td>Madhouse</td>
      <td>TV</td>
      <td>Manga</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>One Piece Fan Letter</td>
      <td>https://myanimelist.net/anime/60022/One_Piece_...</td>
      <td>9.17</td>
      <td>Action, Adventure, Fantasy, Shounen</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV Special</td>
      <td>Light novel</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Fullmetal Alchemist: Brotherhood</td>
      <td>https://myanimelist.net/anime/5114/Fullmetal_A...</td>
      <td>9.09</td>
      <td>Action, Adventure, Drama, Fantasy, Military, S...</td>
      <td>64</td>
      <td>Spring 2009</td>
      <td>Bones</td>
      <td>TV</td>
      <td>Manga</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Steins;Gate</td>
      <td>https://myanimelist.net/anime/9253/Steins_Gate</td>
      <td>9.07</td>
      <td>Drama, Sci-Fi, Suspense, Psychological, Time T...</td>
      <td>24</td>
      <td>Spring 2011</td>
      <td>White Fox</td>
      <td>TV</td>
      <td>Source not found</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Shingeki no Kyojin Season 3 Part 2</td>
      <td>https://myanimelist.net/anime/38524/Shingeki_n...</td>
      <td>9.05</td>
      <td>Action, Drama, Suspense, Gore, Military, Survi...</td>
      <td>10</td>
      <td>Spring 2019</td>
      <td>Wit Studio</td>
      <td>TV</td>
      <td>Manga</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>9839</th>
      <td>9996</td>
      <td>Garugaku. II: Lucky Stars</td>
      <td>https://myanimelist.net/anime/50495/Garugaku_I...</td>
      <td>5.96</td>
      <td>Idols (Female), Music, School</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>OLM</td>
      <td>TV</td>
      <td>Source not found</td>
    </tr>
    <tr>
      <th>9840</th>
      <td>9997</td>
      <td>Guan Hai Ce</td>
      <td>https://myanimelist.net/anime/38689/Guan_Hai_Ce</td>
      <td>5.96</td>
      <td>Action, Fantasy, Historical, Martial Arts, Mil...</td>
      <td>16</td>
      <td>Premiered season not found</td>
      <td>Tong Ming Xuan</td>
      <td>ONA</td>
      <td>Source not found</td>
    </tr>
    <tr>
      <th>9841</th>
      <td>9998</td>
      <td>Hatara Kids Mai Ham Gumi</td>
      <td>https://myanimelist.net/anime/3251/Hatara_Kids...</td>
      <td>5.96</td>
      <td>Action, Kids</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Source not found</td>
    </tr>
    <tr>
      <th>9842</th>
      <td>9999</td>
      <td>Hatsukoi Monster: Mou Chotto dake Tsuzukunja</td>
      <td>https://myanimelist.net/anime/34016/Hatsukoi_M...</td>
      <td>5.96</td>
      <td>Comedy, Romance, School, Shoujo</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Studio Deen</td>
      <td>OVA</td>
      <td>Manga</td>
    </tr>
    <tr>
      <th>9843</th>
      <td>10000</td>
      <td>Hello Kitty no Kieta Santa-san no Boushi</td>
      <td>https://myanimelist.net/anime/22481/Hello_Kitt...</td>
      <td>5.96</td>
      <td>Fantasy, Kids</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>add some</td>
      <td>OVA</td>
      <td>Source not found</td>
    </tr>
  </tbody>
</table>
<p>9844 rows × 10 columns</p>
</div>




```python
super_df.isnull().sum()
```




    Rank          0
    Title         0
    URL           0
    Score         0
    Genres        0
    Episodes     49
    Premiered     0
    Studio        0
    Type          0
    Source        0
    dtype: int64



## Numerical variable

For numerical variable, there are Rank, Score, and Episodes.


```python
# Convert Ranking to numeric values
super_df['Rank'] = pd.to_numeric(super_df['Rank'], errors='coerce')

# Drop rows with invalid rankings
super_df.dropna(subset=['Rank'], inplace=True)

# Summary statistics for ranking
ranking_summary = super_df['Rank'].describe()
print(ranking_summary)


```

    count     9844.000000
    mean      5068.976534
    std       2854.113609
    min          1.000000
    25%       2613.750000
    50%       5075.500000
    75%       7537.250000
    max      10000.000000
    Name: Rank, dtype: float64
    


```python
%matplotlib inline
# Correlation matrix
corr_matrix = super_df.corr()
print(corr_matrix)

# Heatmap of correlation matrix
plt.figure(figsize=(10, 8))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
plt.title('Correlation Matrix Heatmap')
plt.show()
```

                  Rank     Score  Episodes
    Rank      1.000000 -0.977060 -0.010527
    Score    -0.977060  1.000000  0.013211
    Episodes -0.010527  0.013211  1.000000
    


    
![png](output_15_1.png)
    



```python
# Pair plots for numerical variables
sns.pairplot(super_df[['Score', 'Episodes', 'Rank']])
plt.show()
```


    
![png](output_16_0.png)
    


## Categorical variables

For categorical variables, we have multiple plots to see the frequency, as well as how well the variables can predict the average score of the anime.


```python
#Type analysis
super_df['Type'].value_counts().plot(kind='bar', xlabel='class', ylabel='Count', rot= 30)
```




    <Axes: xlabel='class', ylabel='Count'>




    
![png](output_18_1.png)
    



```python
# Average score by type
type_scores = super_df.groupby('Type')['Score'].mean().sort_values(ascending=False)

# Bar plot of average score by type
plt.figure(figsize=(10, 6))
type_scores.plot(kind='bar', alpha=0.7, edgecolor='k')
plt.title('Average Score by Anime Type')
plt.xlabel('Type')
plt.ylabel('Average Score')
plt.show()

# Box plot of score distribution by type
plt.figure(figsize=(10, 6))
sns.boxplot(x='Type', y='Score', data=super_df)
plt.title('Score Distribution by Anime Type')
plt.xlabel('Type')
plt.ylabel('Score')
plt.show()

```


    
![png](output_19_0.png)
    



    
![png](output_19_1.png)
    



```python
# Extract Season and Year from Premiered column
super_df['Premiered'] = super_df['Premiered'].astype(str)  # Ensure it's string type
super_df['Seasonal'] = super_df['Premiered'].apply(lambda x: x.split()[0] if len(x.split()) == 2 else None)
super_df['Year'] = super_df['Premiered'].apply(lambda x: x.split()[1] if len(x.split()) == 2 else None)

# Fill any remaining NaNs with 'Unknown' 
super_df['Seasonal'].fillna('Unknown', inplace=True) 
super_df['Year'].fillna('Unknown', inplace=True)
```


```python
# Loop to convert Year to int except 'Unknown' 
def convert_year(year): 
    try: 
        return int(year) 
    except ValueError: 
        return 'Unknown' 
super_df['Year'] = super_df['Year'].apply(convert_year)
```


```python
#Filter out the unknown year
more_plot = super_df[super_df['Year'] != 'Unknown']

# Count the number of anime titles by type over the years
type_year_counts = more_plot.groupby(['Year', 'Type']).size().unstack(fill_value=0)


# Line plot of number of anime titles by type over the years
plt.figure(figsize=(14, 8))
for anime_type in type_year_counts.columns:
    plt.plot(type_year_counts.index, type_year_counts[anime_type], marker='o', linestyle='-', label=anime_type)

plt.title('Number of Anime Titles by Type Over the Years')
plt.xlabel('Year')
plt.ylabel('Number of Anime Titles')
plt.legend()
plt.grid(True)
plt.xticks(rotation=90)
plt.show()

```


    
![png](output_22_0.png)
    



```python
# Step 1: Split the Genres Column into Lists
super_df['all_Genres'] = super_df['Genres'].str.split(', ')

# Step 2: Get All Unique Genres
all_genres = set(genre for genres in super_df['all_Genres'] for genre in genres)

# Step 3: Create Boolean Columns for Each Genre
for genre in all_genres:
    super_df[genre] = super_df['Genres'].apply(lambda x: genre in x).astype(int)

# Drop the original Genres column if needed
# super_df = super_df.drop(columns=['Genres'])
# List of columns to drop 
columns_to_drop = ['G', 'e', 'n', 'r', 'e','s', 'n','o','t', 'f', 'o', 'u','d'] # Drop the specified columns 
super_df = super_df.drop(columns=columns_to_drop)


# Print the DataFrame
super_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>URL</th>
      <th>Score</th>
      <th>Genres</th>
      <th>Episodes</th>
      <th>Premiered</th>
      <th>Studio</th>
      <th>Type</th>
      <th>Source</th>
      <th>...</th>
      <th>Team Sports</th>
      <th>School</th>
      <th>Shounen</th>
      <th>Samurai</th>
      <th>Time Travel</th>
      <th>Military</th>
      <th>Anthropomorphic</th>
      <th>Supernatural</th>
      <th>Pets</th>
      <th>Gag Humor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Sousou no Frieren</td>
      <td>https://myanimelist.net/anime/52991/Sousou_no_...</td>
      <td>9.32</td>
      <td>Adventure, Drama, Fantasy, Shounen</td>
      <td>28</td>
      <td>Fall 2023</td>
      <td>Madhouse</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>One Piece Fan Letter</td>
      <td>https://myanimelist.net/anime/60022/One_Piece_...</td>
      <td>9.17</td>
      <td>Action, Adventure, Fantasy, Shounen</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV Special</td>
      <td>Light novel</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Fullmetal Alchemist: Brotherhood</td>
      <td>https://myanimelist.net/anime/5114/Fullmetal_A...</td>
      <td>9.09</td>
      <td>Action, Adventure, Drama, Fantasy, Military, S...</td>
      <td>64</td>
      <td>Spring 2009</td>
      <td>Bones</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Steins;Gate</td>
      <td>https://myanimelist.net/anime/9253/Steins_Gate</td>
      <td>9.07</td>
      <td>Drama, Sci-Fi, Suspense, Psychological, Time T...</td>
      <td>24</td>
      <td>Spring 2011</td>
      <td>White Fox</td>
      <td>TV</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Shingeki no Kyojin Season 3 Part 2</td>
      <td>https://myanimelist.net/anime/38524/Shingeki_n...</td>
      <td>9.05</td>
      <td>Action, Drama, Suspense, Gore, Military, Survi...</td>
      <td>10</td>
      <td>Spring 2019</td>
      <td>Wit Studio</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>9839</th>
      <td>9996</td>
      <td>Garugaku. II: Lucky Stars</td>
      <td>https://myanimelist.net/anime/50495/Garugaku_I...</td>
      <td>5.96</td>
      <td>Idols (Female), Music, School</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>OLM</td>
      <td>TV</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9840</th>
      <td>9997</td>
      <td>Guan Hai Ce</td>
      <td>https://myanimelist.net/anime/38689/Guan_Hai_Ce</td>
      <td>5.96</td>
      <td>Action, Fantasy, Historical, Martial Arts, Mil...</td>
      <td>16</td>
      <td>Premiered season not found</td>
      <td>Tong Ming Xuan</td>
      <td>ONA</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9841</th>
      <td>9998</td>
      <td>Hatara Kids Mai Ham Gumi</td>
      <td>https://myanimelist.net/anime/3251/Hatara_Kids...</td>
      <td>5.96</td>
      <td>Action, Kids</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9842</th>
      <td>9999</td>
      <td>Hatsukoi Monster: Mou Chotto dake Tsuzukunja</td>
      <td>https://myanimelist.net/anime/34016/Hatsukoi_M...</td>
      <td>5.96</td>
      <td>Comedy, Romance, School, Shoujo</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Studio Deen</td>
      <td>OVA</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9843</th>
      <td>10000</td>
      <td>Hello Kitty no Kieta Santa-san no Boushi</td>
      <td>https://myanimelist.net/anime/22481/Hello_Kitt...</td>
      <td>5.96</td>
      <td>Fantasy, Kids</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>add some</td>
      <td>OVA</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>9844 rows × 90 columns</p>
</div>




```python
trimmed = super_df.drop_duplicates(['Rank','Title','Score']).reset_index(drop=True)
```


```python
trimmed
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>URL</th>
      <th>Score</th>
      <th>Genres</th>
      <th>Episodes</th>
      <th>Premiered</th>
      <th>Studio</th>
      <th>Type</th>
      <th>Source</th>
      <th>...</th>
      <th>Team Sports</th>
      <th>School</th>
      <th>Shounen</th>
      <th>Samurai</th>
      <th>Time Travel</th>
      <th>Military</th>
      <th>Anthropomorphic</th>
      <th>Supernatural</th>
      <th>Pets</th>
      <th>Gag Humor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Sousou no Frieren</td>
      <td>https://myanimelist.net/anime/52991/Sousou_no_...</td>
      <td>9.32</td>
      <td>Adventure, Drama, Fantasy, Shounen</td>
      <td>28</td>
      <td>Fall 2023</td>
      <td>Madhouse</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>One Piece Fan Letter</td>
      <td>https://myanimelist.net/anime/60022/One_Piece_...</td>
      <td>9.17</td>
      <td>Action, Adventure, Fantasy, Shounen</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV Special</td>
      <td>Light novel</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Fullmetal Alchemist: Brotherhood</td>
      <td>https://myanimelist.net/anime/5114/Fullmetal_A...</td>
      <td>9.09</td>
      <td>Action, Adventure, Drama, Fantasy, Military, S...</td>
      <td>64</td>
      <td>Spring 2009</td>
      <td>Bones</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Steins;Gate</td>
      <td>https://myanimelist.net/anime/9253/Steins_Gate</td>
      <td>9.07</td>
      <td>Drama, Sci-Fi, Suspense, Psychological, Time T...</td>
      <td>24</td>
      <td>Spring 2011</td>
      <td>White Fox</td>
      <td>TV</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Shingeki no Kyojin Season 3 Part 2</td>
      <td>https://myanimelist.net/anime/38524/Shingeki_n...</td>
      <td>9.05</td>
      <td>Action, Drama, Suspense, Gore, Military, Survi...</td>
      <td>10</td>
      <td>Spring 2019</td>
      <td>Wit Studio</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>9738</th>
      <td>9996</td>
      <td>Garugaku. II: Lucky Stars</td>
      <td>https://myanimelist.net/anime/50495/Garugaku_I...</td>
      <td>5.96</td>
      <td>Idols (Female), Music, School</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>OLM</td>
      <td>TV</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9739</th>
      <td>9997</td>
      <td>Guan Hai Ce</td>
      <td>https://myanimelist.net/anime/38689/Guan_Hai_Ce</td>
      <td>5.96</td>
      <td>Action, Fantasy, Historical, Martial Arts, Mil...</td>
      <td>16</td>
      <td>Premiered season not found</td>
      <td>Tong Ming Xuan</td>
      <td>ONA</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9740</th>
      <td>9998</td>
      <td>Hatara Kids Mai Ham Gumi</td>
      <td>https://myanimelist.net/anime/3251/Hatara_Kids...</td>
      <td>5.96</td>
      <td>Action, Kids</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9741</th>
      <td>9999</td>
      <td>Hatsukoi Monster: Mou Chotto dake Tsuzukunja</td>
      <td>https://myanimelist.net/anime/34016/Hatsukoi_M...</td>
      <td>5.96</td>
      <td>Comedy, Romance, School, Shoujo</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Studio Deen</td>
      <td>OVA</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9742</th>
      <td>10000</td>
      <td>Hello Kitty no Kieta Santa-san no Boushi</td>
      <td>https://myanimelist.net/anime/22481/Hello_Kitt...</td>
      <td>5.96</td>
      <td>Fantasy, Kids</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>add some</td>
      <td>OVA</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>9743 rows × 90 columns</p>
</div>




```python
%matplotlib inline
#Split the Genres Column into Lists
super_df['all_Genres'] = super_df['Genres'].str.split(', ')

#Get All Unique Genres
all_genres = set(genre for genres in super_df['all_Genres'] for genre in genres)

# Get the top 20 genres combination by count
top_20_genres = super_df['Genres'].value_counts().nlargest(20)

# Plot the top 20 studios
top_20_genres.plot(kind='bar', xlabel='Genres', ylabel='Count', rot=90)

# Show the plot
plt.figure(figsize=(15, 6)) 
plt.show()
```


    
![png](output_26_0.png)
    



    <Figure size 1500x600 with 0 Axes>



```python
super_df.Episodes.unique()
```




    <IntegerArray>
    [  28,    1,   64,   24,   10,   51,  148,   13, <NA>,  110,
     ...
      510,  263,  312, 1471,  163,  122,  199,  230, 3057,  293]
    Length: 182, dtype: Int64




```python
# Find rows where 'Episodes' column is NaN 
na_rows = super_df[super_df['Episodes'].isna()] 
# Print the rows with NaN values in 'Episodes' column 
print(na_rows)
```

          Rank                                              Title  \
    11      12            Bleach: Sennen Kessen-hen - Soukoku-tan   
    57      58                                          One Piece   
    454    604                                     Ranma ½ (2024)   
    520    670                                  Dragon Ball Daima   
    791    942                          Fairy Tail: 100-nen Quest   
    865   1016                                   Crayon Shin-chan   
    1090  1243                                    Doraemon (2005)   
    1708  1859  Nanatsu no Taizai: Mokushiroku no Yonkishi 2nd...   
    2182  2335                                     Pokemon (2023)   
    2396  2549                                 Wonderful Precure!   
    2417  2570                                           Chiikawa   
    2427  2580  Hifuu Katsudou Kiroku: The Sealed Esoteric His...   
    2506  2659                           Chibi Maruko-chan (1995)   
    2879  3032     Touhou Niji Sousaku Doujin Anime: Musou Kakyou   
    2912  3065                           Ling Jian Zun 4th Season   
    2928  3081                            Kami no Tou: Koubou-sen   
    3167  3320                               Raise wa Tanin ga Ii   
    3581  3734                                    NegaPosi Angler   
    3584  3737                              Ooi! Tonbo 2nd Season   
    3810  3963                     Yamato yo, Towa ni: Rebel 3199   
    3862  4015                                   Nintama Rantarou   
    3942  4095        Re:Zero kara Hajimeru Break Time 3rd Season   
    4080  4233                                    Jueshi Zhan Hun   
    4207  4360                                     Dan Dao Zhizun   
    4403  4556  Saikyou no Shienshoku "Wajutsushi" de Aru Ore ...   
    4756  4909                          Girigiri Warukunai Watame   
    4873  5027                                         Beyblade X   
    4896  5050                                       Dubu Xiaoyao   
    4905  5059                                     Jue Shi Wu Hun   
    5416  5570                                      Wangu Shenhua   
    5432  5586                           Doraemon (2005) Specials   
    5516  5670                                       Ao no Miburo   
    5558  5712                                    Shen Wu Tianzun   
    6280  6435                          Bananya: Around the World   
    6496  6651               Sayounara Ryuusei, Konnichiwa Jinsei   
    6521  6676                                 Sore Ike! Anpanman   
    6726  6881                          Holo no Graffiti Specials   
    6732  6887          Ani x Para: Anata no Hero wa Dare desu ka   
    6761  6916                       MyGO!!!!! Member no Nichijou   
    7467  7622                                 Bonobono (TV 2016)   
    7496  7651                                          Ojarumaru   
    7512  7667                                     Yeosin Gangnim   
    7764  7919                                 Tom to Jerry (ONA)   
    8431  8586                        Neko ni Tensei shita Ojisan   
    8808  8964                                   Himitsu no AiPri   
    8939  9095                                          Sazae-san   
    9147  9303                          6HP (Six Hearts Princess)   
    9617  9774                      Fushigi Dagashiya: Zenitendou   
    9643  9800                                          Hanakappa   
    
                                                        URL  Score  \
    11    https://myanimelist.net/anime/56784/Bleach__Se...   9.01   
    57           https://myanimelist.net/anime/21/One_Piece   8.72   
    454   https://myanimelist.net/anime/59145/Ranma_%C2%...   8.04   
    520   https://myanimelist.net/anime/56894/Dragon_Bal...   7.99   
    791   https://myanimelist.net/anime/49785/Fairy_Tail...   7.84   
    865   https://myanimelist.net/anime/966/Crayon_Shin-...   7.80   
    1090   https://myanimelist.net/anime/8687/Doraemon_2005   7.71   
    1708  https://myanimelist.net/anime/58511/Nanatsu_no...   7.51   
    2182   https://myanimelist.net/anime/53876/Pokemon_2023   7.40   
    2396  https://myanimelist.net/anime/57390/Wonderful_...   7.35   
    2417       https://myanimelist.net/anime/50250/Chiikawa   7.34   
    2427  https://myanimelist.net/anime/36686/Hifuu_Kats...   7.34   
    2506  https://myanimelist.net/anime/6149/Chibi_Maruk...   7.32   
    2879  https://myanimelist.net/anime/9874/Touhou_Niji...   7.25   
    2912  https://myanimelist.net/anime/41884/Ling_Jian_...   7.25   
    2928  https://myanimelist.net/anime/59989/Kami_no_To...   7.24   
    3167  https://myanimelist.net/anime/56964/Raise_wa_T...   7.20   
    3581  https://myanimelist.net/anime/59425/NegaPosi_A...   7.12   
    3584  https://myanimelist.net/anime/59175/Ooi_Tonbo_...   7.12   
    3810  https://myanimelist.net/anime/50855/Yamato_yo_...   7.08   
    3862  https://myanimelist.net/anime/1199/Nintama_Ran...   7.07   
    3942  https://myanimelist.net/anime/60012/Re_Zero_ka...   7.05   
    4080  https://myanimelist.net/anime/58711/Jueshi_Zha...   7.02   
    4207  https://myanimelist.net/anime/57594/Dan_Dao_Zh...   6.99   
    4403  https://myanimelist.net/anime/58714/Saikyou_no...   6.95   
    4756  https://myanimelist.net/anime/51768/Girigiri_W...   6.87   
    4873     https://myanimelist.net/anime/56566/Beyblade_X   6.85   
    4896   https://myanimelist.net/anime/42267/Dubu_Xiaoyao   6.84   
    4905  https://myanimelist.net/anime/43626/Jue_Shi_Wu...   6.84   
    5416  https://myanimelist.net/anime/52623/Wangu_Shenhua   6.74   
    5432  https://myanimelist.net/anime/35686/Doraemon_2...   6.74   
    5516   https://myanimelist.net/anime/56647/Ao_no_Miburo   6.72   
    5558  https://myanimelist.net/anime/50898/Shen_Wu_Ti...   6.72   
    6280  https://myanimelist.net/anime/59666/Bananya__A...   6.59   
    6496  https://myanimelist.net/anime/58445/Sayounara_...   6.56   
    6521  https://myanimelist.net/anime/1960/Sore_Ike_An...   6.55   
    6726  https://myanimelist.net/anime/55593/Holo_no_Gr...   6.52   
    6732  https://myanimelist.net/anime/37290/Ani_x_Para...   6.51   
    6761  https://myanimelist.net/anime/56903/MyGO_Membe...   6.51   
    7467  https://myanimelist.net/anime/32353/Bonobono_T...   6.39   
    7496       https://myanimelist.net/anime/4459/Ojarumaru   6.39   
    7512  https://myanimelist.net/anime/57192/Yeosin_Gan...   6.39   
    7764  https://myanimelist.net/anime/53907/Tom_to_Jer...   6.34   
    8431  https://myanimelist.net/anime/58395/Neko_ni_Te...   6.23   
    8808  https://myanimelist.net/anime/57946/Himitsu_no...   6.16   
    8939       https://myanimelist.net/anime/2406/Sazae-san   6.13   
    9147  https://myanimelist.net/anime/29643/6HP_Six_He...   6.09   
    9617  https://myanimelist.net/anime/42295/Fushigi_Da...   6.01   
    9643       https://myanimelist.net/anime/8336/Hanakappa   6.00   
    
                                                     Genres  Episodes  \
    11             Action, Adventure, Supernatural, Shounen      <NA>   
    57                  Action, Adventure, Fantasy, Shounen      <NA>   
    454   Action, Comedy, Romance, Ecchi, Magical Sex Sh...      <NA>   
    520   Action, Adventure, Comedy, Fantasy, Martial Ar...      <NA>   
    791                 Action, Adventure, Fantasy, Shounen      <NA>   
    865                       Comedy, Ecchi, School, Seinen      <NA>   
    1090     Comedy, Sci-Fi, Anthropomorphic, Kids, Shounen      <NA>   
    1708                Action, Adventure, Fantasy, Shounen      <NA>   
    2182           Action, Adventure, Comedy, Fantasy, Kids      <NA>   
    2396                               Action, Mahou Shoujo      <NA>   
    2417                                     Comedy, Seinen      <NA>   
    2427                                            Fantasy      <NA>   
    2506                             Comedy, School, Shoujo      <NA>   
    2879                                   Fantasy, Vampire      <NA>   
    2912  Action, Adventure, Fantasy, Romance, Martial Arts      <NA>   
    2928         Action, Adventure, Drama, Fantasy, Mystery      <NA>   
    3167                   Romance, Organized Crime, Seinen      <NA>   
    3581                                         Adult Cast      <NA>   
    3584                                      Drama, Sports      <NA>   
    3810  Action, Drama, Sci-Fi, Adult Cast, Military, S...      <NA>   
    3862                                       Comedy, Kids      <NA>   
    3942                                             Comedy      <NA>   
    4080  Action, Adventure, Fantasy, Historical, Martia...      <NA>   
    4207  Action, Adventure, Fantasy, Historical, Martia...      <NA>   
    4403                         Action, Adventure, Fantasy      <NA>   
    4756                                             Comedy      <NA>   
    4873                            Adventure, Sports, Kids      <NA>   
    4896                               Action, Martial Arts      <NA>   
    4905                      Action, Fantasy, Martial Arts      <NA>   
    5416           Action, Adventure, Fantasy, Martial Arts      <NA>   
    5432                                     Comedy, Seinen      <NA>   
    5516               Action, Historical, Samurai, Shounen      <NA>   
    5558                                    Action, Fantasy      <NA>   
    6280               Slice of Life, Anthropomorphic, Kids      <NA>   
    6496          Action, Adventure, Fantasy, Reincarnation      <NA>   
    6521                              Comedy, Fantasy, Kids      <NA>   
    6726                                             Comedy      <NA>   
    6732                                Sports, Educational      <NA>   
    6761                                    Comedy, Gourmet      <NA>   
    7467             Comedy, Slice of Life, Anthropomorphic      <NA>   
    7496    Adventure, Award Winning, Comedy, Fantasy, Kids      <NA>   
    7512                             Comedy, Drama, Romance      <NA>   
    7764                                       Comedy, Kids      <NA>   
    8431                        Comedy, Pets, Reincarnation      <NA>   
    8808                              Idols (Female), Music      <NA>   
    8939                              Comedy, Slice of Life      <NA>   
    9147                              Fantasy, Mahou Shoujo      <NA>   
    9617                                      Mystery, Kids      <NA>   
    9643                                       Comedy, Kids      <NA>   
    
                           Premiered                  Studio        Type  \
    11                     Fall 2024           Pierrot Films          TV   
    57                     Fall 1999          Toei Animation          TV   
    454                    Fall 2024                   MAPPA          TV   
    520                    Fall 2024          Toei Animation          TV   
    791                  Summer 2024               J.C.Staff          TV   
    865                  Spring 1992       Shin-Ei Animation          TV   
    1090                 Spring 2005       Shin-Ei Animation          TV   
    1708                   Fall 2024  Telecom Animation Film          TV   
    2182                 Spring 2023                     OLM          TV   
    2396                 Winter 2024          Toei Animation          TV   
    2417                 Spring 2022               Doga Kobo          TV   
    2427  Premiered season not found                add some         OVA   
    2506                 Winter 1995        Nippon Animation          TV   
    2879  Premiered season not found                add some         OVA   
    2912  Premiered season not found        Suoyi Technology         ONA   
    2928                   Fall 2024       The Answer Studio          TV   
    3167                   Fall 2024             Studio Deen          TV   
    3581                   Fall 2024                     Nut          TV   
    3584                   Fall 2024                     OLM          TV   
    3810  Premiered season not found           studio MOTHER       Movie   
    3862                 Spring 1993                 Ajia-do          TV   
    3942  Premiered season not found          Studio PuYUKAI     Special   
    4080  Premiered season not found                add some         ONA   
    4207  Premiered season not found        Ruo Hong Culture         ONA   
    4403                   Fall 2024              Felix Film          TV   
    4756  Premiered season not found     Hololive Production         ONA   
    4873                   Fall 2023                     OLM          TV   
    4896  Premiered season not found        Suoyi Technology         ONA   
    4905  Premiered season not found        Suoyi Technology         ONA   
    5416  Premiered season not found        Suoyi Technology         ONA   
    5432  Premiered season not found       Shin-Ei Animation  TV Special   
    5516  Premiered season not found               Maho Film          TV   
    5558  Premiered season not found                add some         ONA   
    6280  Premiered season not found       TMS Entertainment         ONA   
    6496  Premiered season not found               SynergySP          TV   
    6521  Premiered season not found       TMS Entertainment          TV   
    6726  Premiered season not found     Hololive Production         ONA   
    6732  Premiered season not found        Nippon Animation  TV Special   
    6761  Premiered season not found          Studio Moriken         ONA   
    7467  Premiered season not found                   Eiken          TV   
    7496  Premiered season not found                  Gallop          TV   
    7512  Premiered season not found                Studio N         ONA   
    7764  Premiered season not found                Fanworks         ONA   
    8431  Premiered season not found      Studio Eight Color          TV   
    8808  Premiered season not found                     OLM          TV   
    8939  Premiered season not found                   Eiken          TV   
    9147  Premiered season not found                Poncotan  TV Special   
    9617  Premiered season not found          Toei Animation          TV   
    9643  Premiered season not found                   Xebec          TV   
    
                    Source  ... Team Sports School Shounen  Samurai  Time Travel  \
    11               Manga  ...           0      0       1        0            0   
    57               Manga  ...           0      0       1        0            0   
    454              Manga  ...           0      1       1        0            0   
    520              Manga  ...           0      0       1        0            0   
    791          Web manga  ...           0      0       1        0            0   
    865              Manga  ...           0      1       0        0            0   
    1090             Manga  ...           0      0       1        0            0   
    1708             Manga  ...           0      0       1        0            0   
    2182  Source not found  ...           0      0       0        0            0   
    2396  Source not found  ...           0      0       0        0            0   
    2417         Web manga  ...           0      0       0        0            0   
    2427  Source not found  ...           0      0       0        0            0   
    2506             Manga  ...           0      1       0        0            0   
    2879  Source not found  ...           0      0       0        0            0   
    2912  Source not found  ...           0      0       0        0            0   
    2928         Web manga  ...           0      0       0        0            0   
    3167             Manga  ...           0      0       0        0            0   
    3581  Source not found  ...           0      0       0        0            0   
    3584             Manga  ...           0      0       0        0            0   
    3810  Source not found  ...           0      0       0        0            0   
    3862             Manga  ...           0      0       0        0            0   
    3942       Light novel  ...           0      0       0        0            0   
    4080  Source not found  ...           0      0       0        0            0   
    4207  Source not found  ...           0      0       0        0            0   
    4403       Light novel  ...           0      0       0        0            0   
    4756  Source not found  ...           0      0       0        0            0   
    4873             Manga  ...           0      0       0        0            0   
    4896  Source not found  ...           0      0       0        0            0   
    4905  Source not found  ...           0      0       0        0            0   
    5416  Source not found  ...           0      0       0        0            0   
    5432  Source not found  ...           0      0       0        0            0   
    5516             Manga  ...           0      0       1        1            0   
    5558             Manga  ...           0      0       0        0            0   
    6280  Source not found  ...           0      0       0        0            0   
    6496       Light novel  ...           0      0       0        0            0   
    6521  Source not found  ...           0      0       0        0            0   
    6726  Source not found  ...           0      0       0        0            0   
    6732  Source not found  ...           0      0       0        0            0   
    6761  Source not found  ...           0      0       0        0            0   
    7467      4-koma manga  ...           0      0       0        0            0   
    7496  Source not found  ...           0      0       0        0            0   
    7512         Web manga  ...           0      0       0        0            0   
    7764  Source not found  ...           0      0       0        0            0   
    8431         Web manga  ...           0      0       0        0            0   
    8808  Source not found  ...           0      0       0        0            0   
    8939      4-koma manga  ...           0      0       0        0            0   
    9147  Source not found  ...           0      0       0        0            0   
    9617  Source not found  ...           0      0       0        0            0   
    9643  Source not found  ...           0      0       0        0            0   
    
          Military  Anthropomorphic  Supernatural  Pets  Gag Humor  
    11           0                0             1     0          0  
    57           0                0             0     0          0  
    454          0                0             0     0          0  
    520          0                0             0     0          0  
    791          0                0             0     0          0  
    865          0                0             0     0          0  
    1090         0                1             0     0          0  
    1708         0                0             0     0          0  
    2182         0                0             0     0          0  
    2396         0                0             0     0          0  
    2417         0                0             0     0          0  
    2427         0                0             0     0          0  
    2506         0                0             0     0          0  
    2879         0                0             0     0          0  
    2912         0                0             0     0          0  
    2928         0                0             0     0          0  
    3167         0                0             0     0          0  
    3581         0                0             0     0          0  
    3584         0                0             0     0          0  
    3810         1                0             0     0          0  
    3862         0                0             0     0          0  
    3942         0                0             0     0          0  
    4080         0                0             0     0          0  
    4207         0                0             0     0          0  
    4403         0                0             0     0          0  
    4756         0                0             0     0          0  
    4873         0                0             0     0          0  
    4896         0                0             0     0          0  
    4905         0                0             0     0          0  
    5416         0                0             0     0          0  
    5432         0                0             0     0          0  
    5516         0                0             0     0          0  
    5558         0                0             0     0          0  
    6280         0                1             0     0          0  
    6496         0                0             0     0          0  
    6521         0                0             0     0          0  
    6726         0                0             0     0          0  
    6732         0                0             0     0          0  
    6761         0                0             0     0          0  
    7467         0                1             0     0          0  
    7496         0                0             0     0          0  
    7512         0                0             0     0          0  
    7764         0                0             0     0          0  
    8431         0                0             0     1          0  
    8808         0                0             0     0          0  
    8939         0                0             0     0          0  
    9147         0                0             0     0          0  
    9617         0                0             0     0          0  
    9643         0                0             0     0          0  
    
    [49 rows x 90 columns]
    


```python
# Replace NaN values in the 'Episodes' column with 1
super_df['Episodes'] = super_df['Episodes'].fillna(1)
super_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>URL</th>
      <th>Score</th>
      <th>Genres</th>
      <th>Episodes</th>
      <th>Premiered</th>
      <th>Studio</th>
      <th>Type</th>
      <th>Source</th>
      <th>...</th>
      <th>Team Sports</th>
      <th>School</th>
      <th>Shounen</th>
      <th>Samurai</th>
      <th>Time Travel</th>
      <th>Military</th>
      <th>Anthropomorphic</th>
      <th>Supernatural</th>
      <th>Pets</th>
      <th>Gag Humor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Sousou no Frieren</td>
      <td>https://myanimelist.net/anime/52991/Sousou_no_...</td>
      <td>9.32</td>
      <td>Adventure, Drama, Fantasy, Shounen</td>
      <td>28</td>
      <td>Fall 2023</td>
      <td>Madhouse</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>One Piece Fan Letter</td>
      <td>https://myanimelist.net/anime/60022/One_Piece_...</td>
      <td>9.17</td>
      <td>Action, Adventure, Fantasy, Shounen</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV Special</td>
      <td>Light novel</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Fullmetal Alchemist: Brotherhood</td>
      <td>https://myanimelist.net/anime/5114/Fullmetal_A...</td>
      <td>9.09</td>
      <td>Action, Adventure, Drama, Fantasy, Military, S...</td>
      <td>64</td>
      <td>Spring 2009</td>
      <td>Bones</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Steins;Gate</td>
      <td>https://myanimelist.net/anime/9253/Steins_Gate</td>
      <td>9.07</td>
      <td>Drama, Sci-Fi, Suspense, Psychological, Time T...</td>
      <td>24</td>
      <td>Spring 2011</td>
      <td>White Fox</td>
      <td>TV</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Shingeki no Kyojin Season 3 Part 2</td>
      <td>https://myanimelist.net/anime/38524/Shingeki_n...</td>
      <td>9.05</td>
      <td>Action, Drama, Suspense, Gore, Military, Survi...</td>
      <td>10</td>
      <td>Spring 2019</td>
      <td>Wit Studio</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>9839</th>
      <td>9996</td>
      <td>Garugaku. II: Lucky Stars</td>
      <td>https://myanimelist.net/anime/50495/Garugaku_I...</td>
      <td>5.96</td>
      <td>Idols (Female), Music, School</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>OLM</td>
      <td>TV</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9840</th>
      <td>9997</td>
      <td>Guan Hai Ce</td>
      <td>https://myanimelist.net/anime/38689/Guan_Hai_Ce</td>
      <td>5.96</td>
      <td>Action, Fantasy, Historical, Martial Arts, Mil...</td>
      <td>16</td>
      <td>Premiered season not found</td>
      <td>Tong Ming Xuan</td>
      <td>ONA</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9841</th>
      <td>9998</td>
      <td>Hatara Kids Mai Ham Gumi</td>
      <td>https://myanimelist.net/anime/3251/Hatara_Kids...</td>
      <td>5.96</td>
      <td>Action, Kids</td>
      <td>50</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9842</th>
      <td>9999</td>
      <td>Hatsukoi Monster: Mou Chotto dake Tsuzukunja</td>
      <td>https://myanimelist.net/anime/34016/Hatsukoi_M...</td>
      <td>5.96</td>
      <td>Comedy, Romance, School, Shoujo</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Studio Deen</td>
      <td>OVA</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9843</th>
      <td>10000</td>
      <td>Hello Kitty no Kieta Santa-san no Boushi</td>
      <td>https://myanimelist.net/anime/22481/Hello_Kitt...</td>
      <td>5.96</td>
      <td>Fantasy, Kids</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>add some</td>
      <td>OVA</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>9844 rows × 90 columns</p>
</div>




```python
# Grouping by genres and calculating average Scores
genre_ranking = super_df.groupby('Genres')['Score'].mean().sort_values()
print(genre_ranking)
```

    Genres
    Action, Fantasy, Historical, Martial Arts, Military                               5.96
    Action, Adventure, Comedy, Historical                                             5.96
    Action, Drama, Sci-Fi, Mecha, Military, Space, Shounen                            5.96
    Horror, School                                                                    5.96
    Award Winning, Drama, Supernatural, Historical                                    5.96
                                                                                      ... 
    Action, Award Winning, Drama, Sci-Fi, Mecha, Military, Super Power                8.91
    Award Winning, Drama, Shounen                                                     8.93
    Drama, Romance, Supernatural, Shoujo                                              8.96
    Action, Comedy, Drama, Sci-Fi, Gag Humor, Historical, Parody, Samurai, Shounen    9.04
    Drama, Sci-Fi, Suspense, Psychological, Time Travel                               9.07
    Name: Score, Length: 3901, dtype: float64
    


```python
# Compute summary statistics for numerical columns 
summary_stats = super_df.describe() 
print(summary_stats) 
# Compute value counts for categorical variables 
super_df['Genres'] = super_df['Genres'].str.split(', ') 
super_df = super_df.explode('Genres')
# Compute value counts for genres 
genre_counts = super_df['Genres'].value_counts() 
print(genre_counts)
studio_counts = super_df['Studio'].value_counts() 
print(studio_counts)
```

                   Rank        Score   Episodes  Combat Sports        Harem  \
    count   9844.000000  9844.000000     9844.0    9844.000000  9844.000000   
    mean    5068.976534     6.915924  15.481004       0.006908     0.044900   
    std     2854.113609     0.624616  50.504744       0.082830     0.207096   
    min        1.000000     5.960000        1.0       0.000000     0.000000   
    25%     2613.750000     6.410000        1.0       0.000000     0.000000   
    50%     5075.500000     6.840000       10.0       0.000000     0.000000   
    75%     7537.250000     7.330000       13.0       0.000000     0.000000   
    max    10000.000000     9.320000     3057.0       1.000000     1.000000   
    
            Villainess        CGDCT  Strategy Game       Comedy   Historical  ...  \
    count  9844.000000  9844.000000    9844.000000  9844.000000  9844.000000  ...   
    mean      0.001219     0.021942       0.018488     0.393742     0.084417  ...   
    std       0.034895     0.146503       0.134716     0.488604     0.278026  ...   
    min       0.000000     0.000000       0.000000     0.000000     0.000000  ...   
    25%       0.000000     0.000000       0.000000     0.000000     0.000000  ...   
    50%       0.000000     0.000000       0.000000     0.000000     0.000000  ...   
    75%       0.000000     0.000000       0.000000     1.000000     0.000000  ...   
    max       1.000000     1.000000       1.000000     1.000000     1.000000  ...   
    
           Team Sports       School      Shounen      Samurai  Time Travel  \
    count  9844.000000  9844.000000  9844.000000  9844.000000  9844.000000   
    mean      0.020622     0.156440     0.170358     0.014831     0.011581   
    std       0.142121     0.363291     0.375966     0.120884     0.106994   
    min       0.000000     0.000000     0.000000     0.000000     0.000000   
    25%       0.000000     0.000000     0.000000     0.000000     0.000000   
    50%       0.000000     0.000000     0.000000     0.000000     0.000000   
    75%       0.000000     0.000000     0.000000     0.000000     0.000000   
    max       1.000000     1.000000     1.000000     1.000000     1.000000   
    
              Military  Anthropomorphic  Supernatural         Pets    Gag Humor  
    count  9844.000000      9844.000000   9844.000000  9844.000000  9844.000000  
    mean      0.052316         0.021434      0.090817     0.007416     0.021638  
    std       0.222675         0.144835      0.287363     0.085799     0.145504  
    min       0.000000         0.000000      0.000000     0.000000     0.000000  
    25%       0.000000         0.000000      0.000000     0.000000     0.000000  
    50%       0.000000         0.000000      0.000000     0.000000     0.000000  
    75%       0.000000         0.000000      0.000000     0.000000     0.000000  
    max       1.000000         1.000000      1.000000     1.000000     1.000000  
    
    [8 rows x 80 columns]
    Comedy       3876
    Action       3527
    Fantasy      2683
    Adventure    2402
    Sci-Fi       1981
                 ... 
    s               9
    t               9
    f               9
    u               9
    d               9
    Name: Genres, Length: 87, dtype: int64
    Toei Animation          2250
    Sunrise                 1925
    add some                1732
    J.C.Staff               1352
    Madhouse                1241
                            ... 
    pH Studio                  1
    PrimeTime                  1
    Heewon Entertainment       1
    Trash Studio               1
    Hong Ying Animation        1
    Name: Studio, Length: 582, dtype: int64
    


```python
# Grouping by individual genres and calculating average scores 
genre_ranking = super_df.groupby('Genres')['Score'].mean().sort_values(ascending=False) 
# Select the top 10 genres 
top_10_genres = genre_ranking.head(15) 
# Bar chart of average scores by top 10 genres 
plt.figure(figsize=(12, 8)) 
top_10_genres.plot(kind='bar', alpha=0.7, edgecolor='k') 
plt.title('Average Scores by Top 10 Individual Genres') 
plt.xlabel('Genre') 
plt.ylabel('Average Score') 
plt.xticks(rotation=90) 
# Save the plot as an image 
plt.savefig('average_scores_by_top_15_individual_genres.png', format='png') 
plt.show()
```


    
![png](output_32_0.png)
    



```python
super_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>URL</th>
      <th>Score</th>
      <th>Genres</th>
      <th>Episodes</th>
      <th>Premiered</th>
      <th>Studio</th>
      <th>Type</th>
      <th>Source</th>
      <th>...</th>
      <th>Team Sports</th>
      <th>School</th>
      <th>Shounen</th>
      <th>Samurai</th>
      <th>Time Travel</th>
      <th>Military</th>
      <th>Anthropomorphic</th>
      <th>Supernatural</th>
      <th>Pets</th>
      <th>Gag Humor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Sousou no Frieren</td>
      <td>https://myanimelist.net/anime/52991/Sousou_no_...</td>
      <td>9.32</td>
      <td>Adventure</td>
      <td>28</td>
      <td>Fall 2023</td>
      <td>Madhouse</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Sousou no Frieren</td>
      <td>https://myanimelist.net/anime/52991/Sousou_no_...</td>
      <td>9.32</td>
      <td>Drama</td>
      <td>28</td>
      <td>Fall 2023</td>
      <td>Madhouse</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Sousou no Frieren</td>
      <td>https://myanimelist.net/anime/52991/Sousou_no_...</td>
      <td>9.32</td>
      <td>Fantasy</td>
      <td>28</td>
      <td>Fall 2023</td>
      <td>Madhouse</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Sousou no Frieren</td>
      <td>https://myanimelist.net/anime/52991/Sousou_no_...</td>
      <td>9.32</td>
      <td>Shounen</td>
      <td>28</td>
      <td>Fall 2023</td>
      <td>Madhouse</td>
      <td>TV</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>One Piece Fan Letter</td>
      <td>https://myanimelist.net/anime/60022/One_Piece_...</td>
      <td>9.17</td>
      <td>Action</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Toei Animation</td>
      <td>TV Special</td>
      <td>Light novel</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>9842</th>
      <td>9999</td>
      <td>Hatsukoi Monster: Mou Chotto dake Tsuzukunja</td>
      <td>https://myanimelist.net/anime/34016/Hatsukoi_M...</td>
      <td>5.96</td>
      <td>Romance</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Studio Deen</td>
      <td>OVA</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9842</th>
      <td>9999</td>
      <td>Hatsukoi Monster: Mou Chotto dake Tsuzukunja</td>
      <td>https://myanimelist.net/anime/34016/Hatsukoi_M...</td>
      <td>5.96</td>
      <td>School</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Studio Deen</td>
      <td>OVA</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9842</th>
      <td>9999</td>
      <td>Hatsukoi Monster: Mou Chotto dake Tsuzukunja</td>
      <td>https://myanimelist.net/anime/34016/Hatsukoi_M...</td>
      <td>5.96</td>
      <td>Shoujo</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>Studio Deen</td>
      <td>OVA</td>
      <td>Manga</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9843</th>
      <td>10000</td>
      <td>Hello Kitty no Kieta Santa-san no Boushi</td>
      <td>https://myanimelist.net/anime/22481/Hello_Kitt...</td>
      <td>5.96</td>
      <td>Fantasy</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>add some</td>
      <td>OVA</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9843</th>
      <td>10000</td>
      <td>Hello Kitty no Kieta Santa-san no Boushi</td>
      <td>https://myanimelist.net/anime/22481/Hello_Kitt...</td>
      <td>5.96</td>
      <td>Kids</td>
      <td>1</td>
      <td>Premiered season not found</td>
      <td>add some</td>
      <td>OVA</td>
      <td>Source not found</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>37840 rows × 90 columns</p>
</div>




```python

# Histograms for numerical features
super_df['Episodes'].hist(bins=30, edgecolor='k', alpha=0.7)
plt.title('Number of Episodes Distribution')
plt.xlabel('Number of Episodes')
plt.ylabel('Frequency')
plt.show()

# Bar plots for categorical variables
genre_counts.plot(kind='bar', figsize=(12, 6), alpha=0.7, edgecolor='k')
plt.title('Genre Frequency')
plt.xlabel('Genre')
plt.ylabel('Frequency')
plt.show()

# Box plots for numerical features across genres
super_df.boxplot(column='Episodes', by='Genres', figsize=(12, 6))
plt.title('Episodes by Genre')
plt.xlabel('Genre')
plt.ylabel('Number of Episodes')
plt.show()


# Select the top 15 genres
top_15_genres = genre_counts.head(15)

# Pie chart of the top 15 genres
plt.figure(figsize=(10, 10))
top_15_genres.plot(kind='pie', autopct='%1.1f%%')
plt.title('Top 15 Genre Proportions')
plt.ylabel('')
plt.show()

```


    
![png](output_34_0.png)
    



    
![png](output_34_1.png)
    



    
![png](output_34_2.png)
    



    
![png](output_34_3.png)
    



```python
#Filter out the unknown year
more_plot1 = super_df[super_df['Seasonal'] != 'Unknown']

# Analysis: Number of anime released each season
season_counts = more_plot1['Seasonal'].value_counts()
print(season_counts)

# Bar plot of number of anime released each season
season_counts.plot(kind='bar', figsize=(10, 6), alpha=0.7, edgecolor='k')
plt.title('Number of Anime Released Each Season')
plt.xlabel('Season')
plt.ylabel('Number of Anime')
plt.show()

# Analysis: Average score by season
season_score = more_plot1.groupby('Seasonal')['Score'].mean().sort_values()
print(season_score)

# Bar plot of average scores by season
season_score.plot(kind='bar', figsize=(10, 6), alpha=0.7, edgecolor='k')
plt.title('Average Scores by Season')
plt.xlabel('Season')
plt.ylabel('Average Score')
plt.show()

# Analysis: Number of anime released each year
year_counts = more_plot['Year'].value_counts().sort_index()
print(year_counts)

# Line plot of number of anime released each year
plt.figure(figsize=(12, 6))
plt.plot(year_counts.index, year_counts.values, marker='o', linestyle='-')
plt.title('Number of Anime Released Each Year')
plt.xlabel('Year')
plt.ylabel('Number of Anime')
plt.grid(True)
plt.xticks(rotation=90)
plt.show()

# Analysis: Average score by year
year_score = more_plot1.groupby('Year')['Score'].mean().sort_index()
print(year_score)

# Line plot of average scores by year
plt.figure(figsize=(12, 6))
plt.plot(year_score.index, year_score.values, marker='o', linestyle='-')
plt.title('Average Scores by Year')
plt.xlabel('Year')
plt.ylabel('Average Score')
plt.grid(True)
plt.xticks(rotation=90)
plt.show()

```

    Fall      3550
    Spring    3526
    Winter    2104
    Summer    2033
    Name: Seasonal, dtype: int64
    


    
![png](output_35_1.png)
    


    Seasonal
    Summer    7.390821
    Winter    7.437001
    Spring    7.456517
    Fall      7.464315
    Name: Score, dtype: float64
    


    
![png](output_35_3.png)
    


    1963      1
    1968      4
    1969      3
    1970      1
    1971      1
    1972      1
    1973      3
    1974      3
    1975      6
    1976      3
    1977      5
    1978     11
    1979      7
    1980      8
    1981     14
    1982     10
    1983     17
    1984     10
    1985     11
    1986      8
    1987     11
    1988     13
    1989     15
    1990     11
    1991     16
    1992     14
    1993     17
    1994     16
    1995     24
    1996     25
    1997     18
    1998     27
    1999     37
    2000     31
    2001     46
    2002     46
    2003     49
    2004     68
    2005     69
    2006     86
    2007     81
    2008     90
    2009     86
    2010     65
    2011     77
    2012     96
    2013     96
    2014    106
    2015     96
    2016    114
    2017     93
    2018    120
    2019     80
    2020     89
    2021    105
    2022    104
    2023    130
    2024    143
    Name: Year, dtype: int64
    


    
![png](output_35_5.png)
    


    Year
    1963    7.080000
    1968    6.825556
    1969    7.242857
    1970    6.760000
    1971    7.620000
    1972    6.940000
    1973    7.258750
    1974    7.378571
    1975    7.206667
    1976    7.340000
    1977    7.401739
    1978    7.438000
    1979    7.630000
    1980    7.327647
    1981    7.115098
    1982    7.414750
    1983    7.171646
    1984    7.282558
    1985    7.306200
    1986    7.474375
    1987    7.358222
    1988    7.202979
    1989    7.301695
    1990    7.097391
    1991    7.307091
    1992    7.500702
    1993    7.313438
    1994    7.334198
    1995    7.344336
    1996    7.408000
    1997    7.337284
    1998    7.319845
    1999    7.379503
    2000    7.231258
    2001    7.270615
    2002    7.410352
    2003    7.306025
    2004    7.335138
    2005    7.395882
    2006    7.365204
    2007    7.454556
    2008    7.328689
    2009    7.438468
    2010    7.412219
    2011    7.527522
    2012    7.498643
    2013    7.402664
    2014    7.480331
    2015    7.412976
    2016    7.451033
    2017    7.579433
    2018    7.495651
    2019    7.645838
    2020    7.494721
    2021    7.590987
    2022    7.596134
    2023    7.521363
    2024    7.531842
    Name: Score, dtype: float64
    


    
![png](output_35_7.png)
    



```python
trimmed.groupby('Year').count()['Rank']
```




    Year
    1963          1
    1968          4
    1969          3
    1970          1
    1971          1
    1972          1
    1973          3
    1974          3
    1975          6
    1976          3
    1977          5
    1978         11
    1979          7
    1980          8
    1981         14
    1982         10
    1983         17
    1984         10
    1985         11
    1986          8
    1987         11
    1988         13
    1989         15
    1990         11
    1991         16
    1992         13
    1993         17
    1994         16
    1995         24
    1996         25
    1997         18
    1998         27
    1999         36
    2000         31
    2001         46
    2002         45
    2003         49
    2004         66
    2005         69
    2006         86
    2007         80
    2008         89
    2009         84
    2010         64
    2011         75
    2012         93
    2013         95
    2014        104
    2015         94
    2016        109
    2017         90
    2018        114
    2019         74
    2020         86
    2021         99
    2022        100
    2023        129
    2024        138
    Unknown    7265
    Name: Rank, dtype: int64




```python
pd.set_option('display.max_columns', 100)
more_plot1[more_plot1['Year']<1975]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>URL</th>
      <th>Score</th>
      <th>Genres</th>
      <th>Episodes</th>
      <th>Premiered</th>
      <th>Studio</th>
      <th>Type</th>
      <th>Source</th>
      <th>Seasonal</th>
      <th>Year</th>
      <th>all_Genres</th>
      <th>Combat Sports</th>
      <th>Harem</th>
      <th>Villainess</th>
      <th>CGDCT</th>
      <th>Strategy Game</th>
      <th>Comedy</th>
      <th>Historical</th>
      <th>Video Game</th>
      <th>Kids</th>
      <th>Magical Sex Shift</th>
      <th>Gore</th>
      <th>Reincarnation</th>
      <th>Psychological</th>
      <th>Award Winning</th>
      <th>Avant Garde</th>
      <th>Educational</th>
      <th>Workplace</th>
      <th>Showbiz</th>
      <th>Mystery</th>
      <th>Suspense</th>
      <th>Vampire</th>
      <th>Girls Love</th>
      <th>Racing</th>
      <th>Urban Fantasy</th>
      <th>Space</th>
      <th>Childcare</th>
      <th>Visual Arts</th>
      <th>Boys Love</th>
      <th>Love Status Quo</th>
      <th>Performing Arts</th>
      <th>Idols (Female)</th>
      <th>Romance</th>
      <th>Adult Cast</th>
      <th>Organized Crime</th>
      <th>Music</th>
      <th>Horror</th>
      <th>Reverse Harem</th>
      <th>Mecha</th>
      <th>Drama</th>
      <th>Action</th>
      <th>Parody</th>
      <th>Otaku Culture</th>
      <th>Sports</th>
      <th>Medical</th>
      <th>Mahou Shoujo</th>
      <th>Slice of Life</th>
      <th>Seinen</th>
      <th>Isekai</th>
      <th>Martial Arts</th>
      <th>Shoujo</th>
      <th></th>
      <th>Adventure</th>
      <th>Delinquents</th>
      <th>Fantasy</th>
      <th>Detective</th>
      <th>Mythology</th>
      <th>Idols (Male)</th>
      <th>Iyashikei</th>
      <th>Ecchi</th>
      <th>High Stakes Game</th>
      <th>Survival</th>
      <th>Gourmet</th>
      <th>Sci-Fi</th>
      <th>Super Power</th>
      <th>Josei</th>
      <th>Crossdressing</th>
      <th>Love Polygon</th>
      <th>Team Sports</th>
      <th>School</th>
      <th>Shounen</th>
      <th>Samurai</th>
      <th>Time Travel</th>
      <th>Military</th>
      <th>Anthropomorphic</th>
      <th>Supernatural</th>
      <th>Pets</th>
      <th>Gag Humor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1329</th>
      <td>1483</td>
      <td>Lupin III</td>
      <td>https://myanimelist.net/anime/1412/Lupin_III</td>
      <td>7.62</td>
      <td>Action</td>
      <td>23</td>
      <td>Fall 1971</td>
      <td>Tokyo Movie Shinsha</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Fall</td>
      <td>1971</td>
      <td>[Action, Adventure, Comedy, Mystery, Adult Cas...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1329</th>
      <td>1483</td>
      <td>Lupin III</td>
      <td>https://myanimelist.net/anime/1412/Lupin_III</td>
      <td>7.62</td>
      <td>Adventure</td>
      <td>23</td>
      <td>Fall 1971</td>
      <td>Tokyo Movie Shinsha</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Fall</td>
      <td>1971</td>
      <td>[Action, Adventure, Comedy, Mystery, Adult Cas...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1329</th>
      <td>1483</td>
      <td>Lupin III</td>
      <td>https://myanimelist.net/anime/1412/Lupin_III</td>
      <td>7.62</td>
      <td>Comedy</td>
      <td>23</td>
      <td>Fall 1971</td>
      <td>Tokyo Movie Shinsha</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Fall</td>
      <td>1971</td>
      <td>[Action, Adventure, Comedy, Mystery, Adult Cas...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1329</th>
      <td>1483</td>
      <td>Lupin III</td>
      <td>https://myanimelist.net/anime/1412/Lupin_III</td>
      <td>7.62</td>
      <td>Mystery</td>
      <td>23</td>
      <td>Fall 1971</td>
      <td>Tokyo Movie Shinsha</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Fall</td>
      <td>1971</td>
      <td>[Action, Adventure, Comedy, Mystery, Adult Cas...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1329</th>
      <td>1483</td>
      <td>Lupin III</td>
      <td>https://myanimelist.net/anime/1412/Lupin_III</td>
      <td>7.62</td>
      <td>Adult Cast</td>
      <td>23</td>
      <td>Fall 1971</td>
      <td>Tokyo Movie Shinsha</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Fall</td>
      <td>1971</td>
      <td>[Action, Adventure, Comedy, Mystery, Adult Cas...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>5341</th>
      <td>5495</td>
      <td>Gegege no Kitarou (1968)</td>
      <td>https://myanimelist.net/anime/5688/Gegege_no_K...</td>
      <td>6.76</td>
      <td>Adventure</td>
      <td>65</td>
      <td>Winter 1968</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Winter</td>
      <td>1968</td>
      <td>[Adventure, Comedy, Fantasy, Horror, Supernatu...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5341</th>
      <td>5495</td>
      <td>Gegege no Kitarou (1968)</td>
      <td>https://myanimelist.net/anime/5688/Gegege_no_K...</td>
      <td>6.76</td>
      <td>Comedy</td>
      <td>65</td>
      <td>Winter 1968</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Winter</td>
      <td>1968</td>
      <td>[Adventure, Comedy, Fantasy, Horror, Supernatu...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5341</th>
      <td>5495</td>
      <td>Gegege no Kitarou (1968)</td>
      <td>https://myanimelist.net/anime/5688/Gegege_no_K...</td>
      <td>6.76</td>
      <td>Fantasy</td>
      <td>65</td>
      <td>Winter 1968</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Winter</td>
      <td>1968</td>
      <td>[Adventure, Comedy, Fantasy, Horror, Supernatu...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5341</th>
      <td>5495</td>
      <td>Gegege no Kitarou (1968)</td>
      <td>https://myanimelist.net/anime/5688/Gegege_no_K...</td>
      <td>6.76</td>
      <td>Horror</td>
      <td>65</td>
      <td>Winter 1968</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Winter</td>
      <td>1968</td>
      <td>[Adventure, Comedy, Fantasy, Horror, Supernatu...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5341</th>
      <td>5495</td>
      <td>Gegege no Kitarou (1968)</td>
      <td>https://myanimelist.net/anime/5688/Gegege_no_K...</td>
      <td>6.76</td>
      <td>Supernatural</td>
      <td>65</td>
      <td>Winter 1968</td>
      <td>Toei Animation</td>
      <td>TV</td>
      <td>Manga</td>
      <td>Winter</td>
      <td>1968</td>
      <td>[Adventure, Comedy, Fantasy, Horror, Supernatu...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>80 rows × 90 columns</p>
</div>




```python
super_df['Year'].describe()
```




    count       37840
    unique         59
    top       Unknown
    freq        26627
    Name: Year, dtype: object




```python
# Genre popularity and trends
genre_combinations = super_df['Genres'].value_counts()
print(genre_combinations)

df_2000s = more_plot1[more_plot1['Year'] >= 2000]


#analyze genre trends over time if you have a 'Year' column
# Count the number of anime by genre for each year 
genre_year_counts = df_2000s.groupby(['Year', 'Genres']).size().reset_index(name='Count')

# Pivot the table to have years as rows and genres as columns 
pivot_table = genre_year_counts.pivot(index='Year', columns='Genres', values='Count').fillna(0) 
# Plot the trends of a few selected genres over time 
genres_to_plot = ['School', 'Adventure', 'Comedy', 'Drama', 'Fantasy','Romance','Isekai'] 
# Select genres of interest 
plt.figure(figsize=(14, 8)) 
for genre in genres_to_plot: 
    if genre in pivot_table.columns: 
        plt.plot(pivot_table.index, pivot_table[genre], marker='o', label=genre) 
    
plt.title('Genre Trends Over Time') 
plt.xlabel('Year') 
plt.ylabel('Number of Anime') 
plt.legend() 
plt.grid(True) 
plt.xticks(rotation=90) 
plt.show()
```

    Comedy       3876
    Action       3527
    Fantasy      2683
    Adventure    2402
    Sci-Fi       1981
                 ... 
    s               9
    t               9
    f               9
    u               9
    d               9
    Name: Genres, Length: 87, dtype: int64
    


    
![png](output_39_1.png)
    



```python
# Plot the trends of a few selected genres over time 
genres_to_plot = ['Fantasy','Isekai'] 
# Select genres of interest 
plt.figure(figsize=(14, 8)) 
for genre in genres_to_plot: 
    if genre in pivot_table.columns: 
        plt.plot(pivot_table.index, pivot_table[genre], marker='o', label=genre) 
    
plt.title('Genre Trends Over Time') 
plt.xlabel('Year') 
plt.ylabel('Number of Anime') 
plt.legend() 
plt.grid(True) 
plt.xticks(rotation=30) 
plt.show()
```


    
![png](output_40_0.png)
    



```python
from wordcloud import WordCloud

# Create a word cloud for anime titles or synopses
text = " ".join(title for title in more_plot['Title'])
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(text)

plt.figure(figsize=(10, 6))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.show()
```


    
![png](output_41_0.png)
    



```python
# Average score by source
source_scores = super_df.groupby('Source')['Score'].mean().sort_values(ascending=False)

# Bar plot of average score by source
plt.figure(figsize=(10, 6))
source_scores.plot(kind='bar', alpha=0.7, edgecolor='k')
plt.title('Average Score by Anime Source')
plt.xlabel('Source')
plt.ylabel('Average Score')
plt.show()

# Box plot of score distribution by source
plt.figure(figsize=(10, 6))
sns.boxplot(x='Source', y='Score', data=super_df)
plt.title('Score Distribution by Anime Source')
plt.xlabel('Source')
plt.ylabel('Score')
plt.show()

```


    
![png](output_42_0.png)
    



    
![png](output_42_1.png)
    



```python
# Average number of episodes by source
source_episodes = super_df.groupby('Source')['Episodes'].mean().sort_values(ascending=False)

# Bar plot of average number of episodes by source
plt.figure(figsize=(10, 6))
source_episodes.plot(kind='bar', alpha=0.7, edgecolor='k')
plt.title('Average Number of Episodes by Anime Source')
plt.xlabel('Source')
plt.ylabel('Average Number of Episodes')
plt.show()

# Box plot of episode distribution by source
plt.figure(figsize=(10, 6))
sns.boxplot(x='Source', y='Episodes', data=super_df)
plt.title('Episode Distribution by Anime Source')
plt.xlabel('Source')
plt.ylabel('Number of Episodes')
plt.show()

```


    
![png](output_43_0.png)
    



    
![png](output_43_1.png)
    



```python
# Count the number of genres by source
source_genre_counts = super_df.groupby(['Source', 'Genres']).size().unstack(fill_value=0)

# Heatmap of genre distribution by source
plt.figure(figsize=(14, 10))
sns.heatmap(source_genre_counts, cmap='coolwarm', linewidths=0.5)
plt.title('Genre Distribution by Anime Source')
plt.xlabel('Genre')
plt.ylabel('Source')
plt.show()

```


    
![png](output_44_0.png)
    



```python
%matplotlib inline
# Get the top 20 studios by count
top_20_studios = super_df['Studio'].value_counts().nlargest(20)
print(top_20_studios)
# Plot the top 20 studios
top_20_studios.plot(kind='bar', xlabel='Studio', ylabel='Count', rot=70)

# Show the plot
plt.figure(figsize=(16, 8)) 
plt.show()
```

    Toei Animation          2250
    Sunrise                 1925
    add some                1732
    J.C.Staff               1352
    Madhouse                1241
    Production I.G          1169
    Studio Deen             1089
    TMS Entertainment       1041
    Pierrot                  917
    OLM                      912
    A-1 Pictures             772
    Shin-Ei Animation        699
    Bones                    623
    Nippon Animation         550
    Gonzo                    545
    Xebec                    510
    AIC                      507
    Shaft                    472
    SILVER LINK.             459
    Tatsunoko Production     458
    Name: Studio, dtype: int64
    


    
![png](output_45_1.png)
    



    <Figure size 1600x800 with 0 Axes>



```python
# Calculate the average score by studio and sort values in descending order
studio_scores = super_df.groupby('Studio')['Score'].mean().sort_values(ascending=False)

# Top rated studios based on average score
top_studios = studio_scores.head(10)
print(top_studios)

# Bar plot of average score by top 10 studios
plt.figure(figsize=(14, 8))
top_studios.plot(kind='bar', alpha=0.7, edgecolor='k')
plt.title('Average Score by Top 10 Studios')
plt.xlabel('Studio')
plt.ylabel('Average Score')
plt.show()

```

    Studio
    Pierrot Films               9.010000
    Studio DURIAN               8.890000
    K-Factory                   8.491818
    Nippon Ramayana Film Co.    8.390000
    Studio M2                   8.159474
    Studio Bind                 8.146750
    Sharefun Studio             8.042500
    Shenman Entertainment       8.007143
    Samsara Animation Studio    7.952727
    Shuka                       7.930789
    Name: Score, dtype: float64
    


    
![png](output_46_1.png)
    



```python
# Count the number of anime titles released by each studio over the years
studio_year_counts = more_plot.groupby(['Year', 'Studio']).size().unstack(fill_value=0)

# Plotting the number of anime titles released by a few selected studios over time
studios_to_plot = ['Toei Animation', 'Sunrise', 'J.C.Staff','Pierrot']  # Replace with actual studio names
plt.figure(figsize=(18, 8))

for studio in studios_to_plot:
    if studio in studio_year_counts.columns:
        plt.plot(studio_year_counts.index, studio_year_counts[studio], marker='o', label=studio)

plt.title('Studio Activity Over Time')
plt.xlabel('Year')
plt.ylabel('Number of Anime Titles')
plt.legend()
plt.grid(True)
plt.xticks(rotation=90)
plt.show()

```


    
![png](output_47_0.png)
    



```python
# Assuming there is a column 'Season' in the dataset
# Average number of episodes per series by season
episodes_per_season = super_df.groupby('Seasonal')['Episodes'].mean().sort_values()

# Bar plot of average number of episodes per series by season
plt.figure(figsize=(14, 8))
episodes_per_season.plot(kind='bar', alpha=0.7, edgecolor='k')
plt.title('Average Number of Episodes per Series by Season')
plt.xlabel('Season')
plt.ylabel('Average Number of Episodes')
plt.show()

```


    
![png](output_48_0.png)
    



```python
# Popular genres by season 
popular_genres_by_season = super_df.groupby(['Seasonal', 'Genres']).size().unstack(fill_value=0) 
# Heatmap of popular genres by season 
plt.figure(figsize=(14, 10)) 
sns.heatmap(popular_genres_by_season, cmap='coolwarm', linewidths=0.5) 
plt.title('Popular Genres by Season') 
plt.xlabel('Genre') 
plt.ylabel('Season')
plt.show()
```


    
![png](output_49_0.png)
    



```python
# Number of episodes over time
episodes_per_year = more_plot.groupby('Year')['Episodes'].mean()

# Line plot of average number of episodes per series over the years
plt.figure(figsize=(14, 8))
plt.plot(episodes_per_year.index, episodes_per_year.values, marker='o', linestyle='-')
plt.title('Average Number of Episodes per Series Over the Years')
plt.xlabel('Year')
plt.ylabel('Average Number of Episodes')
plt.grid(True)
plt.xticks(rotation=90)
plt.show()

plt.savefig('Average Number of Episodes per Series over the Years.png', format='png')
```


    
![png](output_50_0.png)
    



    <Figure size 640x480 with 0 Axes>



```python
# Top genres by decade
more_plot1['Decade'] = (more_plot1['Year'] // 10) * 10
decade_genre_counts = more_plot1.groupby(['Decade', 'Genres']).size().unstack(fill_value=0)

# Plot of top genres by decade
plt.figure(figsize=(14, 10))
sns.heatmap(decade_genre_counts, cmap='coolwarm', linewidths=0.5)
plt.title('Top Genres by Decade')
plt.xlabel('Genre')
plt.ylabel('Decade')
plt.show()

```

    C:\Users\sylan\AppData\Local\Temp\ipykernel_2208\1741430397.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      more_plot1['Decade'] = (more_plot1['Year'] // 10) * 10
    


    
![png](output_51_1.png)
    



```python
import statsmodels.api as sm
from statsmodels.formula.api import ols

# ANOVA for Genres
model_genre = ols('Score ~ C(Genres)', data=super_df).fit()
anova_table_genre = sm.stats.anova_lm(model_genre, typ=2)
print("ANOVA Table for Genres:")
print(anova_table_genre)

# ANOVA for Type
model_type = ols('Score ~ C(Type)', data=super_df).fit()
anova_table_type = sm.stats.anova_lm(model_type, typ=2)
print("\nANOVA Table for Type:")
print(anova_table_type)

# ANOVA for Season
model_season = ols('Score ~ C(Seasonal)', data=super_df).fit()
anova_table_season = sm.stats.anova_lm(model_season, typ=2)
print("\nANOVA Table for Season:")
print(anova_table_season)

# ANOVA for Year
model_year = ols('Score ~ C(Year)', data=super_df).fit()
anova_table_year = sm.stats.anova_lm(model_year, typ=2)
print("\nANOVA Table for Year:")
print(anova_table_year)

# Visualization for Genres
plt.figure(figsize=(14, 8))
sns.barplot(x='Genres', y='Score', data=super_df, ci=None)
plt.title('Average Score by Genre')
plt.xlabel('Genre')
plt.ylabel('Average Score')
plt.xticks(rotation=90)
plt.savefig('average_score_by_genre.png', format='png')
plt.show()

# Visualization for Type
plt.figure(figsize=(10, 6))
sns.barplot(x='Type', y='Score', data=super_df, ci=None)
plt.title('Average Score by Type')
plt.xlabel('Type')
plt.ylabel('Average Score')
plt.savefig('average_score_by_type.png', format='png')
plt.show()

# Visualization for Season
plt.figure(figsize=(10, 6))
sns.barplot(x='Seasonal', y='Score', data=super_df, ci=None)
plt.title('Average Score by Season')
plt.xlabel('Season')
plt.ylabel('Average Score')
plt.savefig('average_score_by_season.png', format='png')
plt.show()

# Visualization for Year
plt.figure(figsize=(14, 8))
sns.barplot(x='Year', y='Score', data=super_df, ci=None)
plt.title('Average Score by Year')
plt.xlabel('Year')
plt.ylabel('Average Score')
plt.xticks(rotation=90)
plt.savefig('average_score_by_year.png', format='png')
plt.show()

```

    ANOVA Table for Genres:
                     sum_sq       df         F  PR(>F)
    C(Genres)    906.339205     86.0  27.51558     0.0
    Residual   14459.893920  37753.0       NaN     NaN
    
    ANOVA Table for Type:
                    sum_sq       df           F         PR(>F)
    C(Type)     503.380276      5.0  256.275017  2.671507e-270
    Residual  14862.852850  37834.0         NaN            NaN
    
    ANOVA Table for Season:
                       sum_sq       df           F  PR(>F)
    C(Seasonal)   3222.545789      4.0  2510.04939     0.0
    Residual     12143.687336  37835.0         NaN     NaN
    
    ANOVA Table for Year:
                    sum_sq       df           F  PR(>F)
    C(Year)    3348.887478     58.0  181.525423     0.0
    Residual  12017.345647  37781.0         NaN     NaN
    


    
![png](output_52_1.png)
    



    
![png](output_52_2.png)
    



    
![png](output_52_3.png)
    



    
![png](output_52_4.png)
    


## Summary

### Numerical variable:
- Episode has no correlation with score or ranking.

### Categorical variable:

- F-Statistics Summary:
    - Genres: 27.51558

    - Type: 256.275017

    - Season: 2510.04939

    - Year: 181.525423

- Interpretation:
    - Strongest Predictor: Season (F-statistic: 2510.04939)

        - This indicates that the season in which an anime was released is the most influential predictor of its average score among the variables tested.

    - Weakest Predictor: Genres (F-statistic: 27.51558)

        - This suggests that the genre of an anime, while still statistically significant, has the least influence on its average score compared to the other variables.


```python

```
